package com.nicepay.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF142B55)
private val Blue = Color(0xFF246BFD)
private val Pale = Color(0xFFF3F6FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NicePayApp() }
    }
}

@Composable
fun NicePayApp() {
    var selected by remember { mutableStateOf("Home") }
    var showInfo by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Pale)) {
        Scaffold(
            containerColor = Pale,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Home", "Activity", "Profile").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = { Text(when(item) { "Home" -> "⌂"; "Activity" -> "↻"; else -> "●" }, fontSize = 20.sp) },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("NicePay", color = Navy, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        Text("Simple. Smart. Secure.", color = Color.Gray, fontSize = 13.sp)
                    }
                    Text("NP", color = Color.White, fontWeight = FontWeight.Bold,
                        modifier = Modifier.background(Blue, RoundedCornerShape(14.dp)).padding(14.dp))
                }

                Card(colors = CardDefaults.cardColors(containerColor = Navy),
                    shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(22.dp)) {
                        Text("Demo wallet balance", color = Color.White.copy(alpha = .75f))
                        Spacer(Modifier.height(8.dp))
                        Text("₹ 0.00", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Sample screen — no real money is held.", color = Color.White.copy(alpha = .75f), fontSize = 12.sp)
                    }
                }

                Text("Quick actions", color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionCard("Send", "UPI transfer", Modifier.weight(1f)) { showInfo = true }
                    ActionCard("Add money", "Wallet top-up", Modifier.weight(1f)) { showInfo = true }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionCard("Withdraw", "To bank / UPI", Modifier.weight(1f)) { showInfo = true }
                    ActionCard("Rewards", "Earn points", Modifier.weight(1f)) { showInfo = true }
                }

                Text("Recent activity", color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Card(colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("No transactions yet", color = Navy, fontWeight = FontWeight.SemiBold)
                        Text("Your activity will appear here.", color = Color.Gray, fontSize = 13.sp)
                    }
                }
                if (showInfo) {
                    AlertDialog(
                        onDismissRequest = { showInfo = false },
                        title = { Text("Demo feature") },
                        text = { Text("This starter app does not move real money. UPI, wallet, KYC and payouts need an approved payment partner and secure backend.") },
                        confirmButton = { TextButton(onClick = { showInfo = false }) { Text("OK") } }
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier.height(104.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.Center) {
            Text(title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Color.Gray, fontSize = 11.sp)
        }
    }
}
