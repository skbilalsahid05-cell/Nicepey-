# NicePay Android Starter

This is a starter Android app project for the NicePay concept. It contains a simple demo wallet interface and a GitHub Actions workflow that builds a test APK in the cloud.

## Build the APK using GitHub on your Android phone

1. Download and extract this ZIP on your phone.
2. Open your GitHub repository named `NicePay`.
3. Choose **Add file → Upload files**.
4. Upload the contents inside this extracted folder (not the ZIP file itself). Keep the folders such as `app` and `.github` intact.
5. Scroll down and press **Commit changes**.
6. Open the repository's **Actions** tab.
7. Open **Build NicePay APK** and wait for the workflow to finish successfully.
8. Open the completed run and download the **NicePay-debug-apk** artifact.

## Important

- This is a starter/demo app, not a live payment or earning service.
- It does not connect to UPI, a bank, a wallet provider, KYC, ads, or a server.
- Do not collect real users' payment details or promise real earnings with this demo.
- Real UPI transfers, wallet balances, deposits and withdrawals require an approved payment/PPI partner, a secure backend, compliance checks, testing and security controls.
- The debug APK is for testing. A Play Store release requires a properly signed Android App Bundle (AAB), store listing, privacy policy, and current Play Console requirements.
- Package ID: `com.nicepay.app`
